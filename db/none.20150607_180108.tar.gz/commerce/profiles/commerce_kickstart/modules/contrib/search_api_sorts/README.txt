
Search sorts
-------------

This module allows you to enable a block with custom sort options.
