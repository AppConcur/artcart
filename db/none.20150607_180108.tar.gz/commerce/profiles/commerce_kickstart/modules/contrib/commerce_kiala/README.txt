Commerce Kiala is packaged for download at http://drupal.org/project/commerce_kiala.
Learn more at http://drupal.org/node/1842672
