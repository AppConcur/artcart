An example migration from comma separated value files into Drupal nodes. Also a
good example of a DynamicMigration (i.e. the same migration class handles
multiple migrations).

We currently depend on Features module just for easy export of a content type.

The data comes from http://www.retrosheet.org/gamelogs/index.html:

The information used here was obtained free of charge from and is copyrighted by
Retrosheet.  Interested parties may contact Retrosheet at "www.retrosheet.org".
